Sample configuration files for:
```
SystemD: ultichaind.service
Upstart: ultichaind.conf
OpenRC:  ultichaind.openrc
         ultichaind.openrcconf
CentOS:  ultichaind.init
OS X:    org.ultichain.ultichaind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
